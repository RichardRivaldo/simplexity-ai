from src.ai.local_search import *
from src.ai.minimax import *
